#!/bin/sh
./configure CFLAGS="-O3" TCL_PREFIX=../tcl853_include_win TCL_VERSION=85 --with-memwatch --with-tkputs --with-debug
#./configure CFLAGS="-O3" TCL_PREFIX=c:/tcl832 TCL_VERSION=83 --with-memwatch --with-tkputs --with-debug
