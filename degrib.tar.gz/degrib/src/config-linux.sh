#!/bin/sh
./configure CFLAGS="-O3"
#configure CFLAGS="-O3" TCL_PREFIX=/usr/local/tcltk
#configure CFLAGS="-O3" TCL_PREFIX=/usr/local/tcltk --with-halo
#configure CFLAGS="-O3" --with-halo CC=gcc34
