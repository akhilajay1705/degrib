#!/bin/sh
./configure CFLAGS="-O3"
#configure CFLAGS="-O3" TCL_PREFIX=/usr/local/tcltk
